let hours_worked = 35
